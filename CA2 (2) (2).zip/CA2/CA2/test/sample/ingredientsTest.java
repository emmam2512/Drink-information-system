package sample;

import org.junit.jupiter.api.Test;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;


class ingredientsTest {
    private ingredients ingredient1;
    private ingredients ingredient2;
    private ingredients ingredient3;

    ingredientsTest() {
    }

    @BeforeEach
    void setUp() {
        this.ingredient1 = new ingredients("Vodka", "strong", 37);
        this.ingredient2 = new ingredients("Gin", "light", 40);
        this.ingredient3 = new ingredients("Bacardi", "sweet", 12);
    }

    @AfterEach
    void tearDown() {
        this.ingredient1 = this.ingredient2 = this.ingredient3 = null;
    }

    @Test
    public void getIngredientName() {
        Assertions.assertEquals("Vodka", this.ingredient1.getIngredientName());
        Assertions.assertEquals("Gin", this.ingredient2.getIngredientName());
        Assertions.assertEquals("Bacardi", this.ingredient3.getIngredientName());
    }

    @Test
    public void getIngredientDescription() {
        Assertions.assertEquals("strong", this.ingredient1.getIngredientDescription());
        Assertions.assertEquals("light", this.ingredient2.getIngredientDescription());
        Assertions.assertEquals("sweet", this.ingredient3.getIngredientDescription());
    }

    @Test
    public void getAlcoholContent() {
        Assertions.assertEquals(37, this.ingredient1.getAlcoholContent());
        Assertions.assertEquals(40, this.ingredient2.getAlcoholContent());
        Assertions.assertEquals(12, this.ingredient3.getAlcoholContent());
    }

    @Test
    void setIngredientName() {
        this.ingredient1.setIngredientName("Vodka");
        Assertions.assertEquals("Vodka", this.ingredient1.getIngredientName());
        this.ingredient2.setIngredientName("Gin");
        Assertions.assertEquals("Gin", this.ingredient2.getIngredientName());
        this.ingredient3.setIngredientName("Bacardi");
        Assertions.assertEquals("Bacardi", this.ingredient3.getIngredientName());
    }

    @Test
    void setIngredientDescription() {
        this.ingredient1.setIngredientDescription("strong");
        Assertions.assertEquals("strong", this.ingredient1.getIngredientDescription());
        this.ingredient2.setIngredientDescription("light");
        Assertions.assertEquals("light", this.ingredient2.getIngredientDescription());
        this.ingredient1.setIngredientDescription("sweet");
        Assertions.assertEquals("sweet", this.ingredient3.getIngredientDescription());
    }

    @Test
    void setAlcoholContent() {
        this.ingredient1.setAlcoholContent(37);
        Assertions.assertEquals(37, this.ingredient1.getAlcoholContent());
        this.ingredient2.setAlcoholContent(40);
        Assertions.assertEquals(40, this.ingredient2.getAlcoholContent());
        this.ingredient1.setAlcoholContent(12);
        Assertions.assertEquals(12, this.ingredient3.getAlcoholContent());
    }

    @Test
    void testToString() {
        Assertions.assertEquals("Vodka", this.ingredient1.toString());
    }
}
